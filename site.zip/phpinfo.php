<?php
phpinfo ();
?>
